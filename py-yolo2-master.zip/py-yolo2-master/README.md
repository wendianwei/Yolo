# py-yolo2

just cmake .. && make

use yolo.py to test your model in python
