cd examples/yolo/darknet_tree
./train_darknet_tree.sh
